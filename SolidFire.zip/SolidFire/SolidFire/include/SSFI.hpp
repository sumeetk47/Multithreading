#ifndef _SSFI_H
#define _SSFI_H
/*
@brief 
	SSFI - Super Simple File Indexer 
	Responsible for main implementation of SSFI
	1) Spawns Worker Threads and Search Thread
	2) Sorts the Map of Words 
	3) Displays top words in descending order 

*/

#include "../include/SSFIdefaulttypes.hpp"


class SSFI{
	private:
			int s_topWordsList;
			Parameters_t *s_inputParameters;
			mapCopy_t *sortWordMap(wordMap_t *wordMap);	
			void printTopWords(mapCopy_t *mapcopy,int numTopWords);
	public:
			SSFI(int topWordsList=10);//default if not specified 
			void setSSFIInput(Parameters_t *inputParameters);			
			void SimpleFileIndexer();

};

#endif

