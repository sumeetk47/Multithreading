#ifndef _WORKERMANAGER_H
#define _WORKERMANAGER_H

/*
@brief
Worker Thread 
-------------
WorkerManager.cpp
	Implements the Worker Thread functionality 
	1.Dequeue filepaths from "Synchronized Queue"
	2.To parse words from text File with non-alphanumeric elements acting as delimiter
	3.Store unique words and repeat element in a Map

*/


#include <iostream>
#include <mutex>
#include "../include/SSFIdefaulttypes.hpp"
#include "boost/filesystem/path.hpp"
#include "../include/SyncQueue.hpp"

class Worker{

private :
	int w_id;//id of the Worker
	SynchronizedQueue<path>*w_queue;//
	wordMap_t *w_wordMap;
	void wordCounter(wordMap_t *wordMap,SynchronizedQueue<path> *m_queue);

public:

	void setup(int id,SynchronizedQueue<path>*queue,wordMap_t *wordMap)	;
	void operator()(){
	wordCounter(w_wordMap,w_queue);
}

}; 

#endif