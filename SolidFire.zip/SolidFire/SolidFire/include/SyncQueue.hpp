#ifndef _SYNCQUEUE_H
#define _SYNCQUEUE_H

#include <iostream>
#include <mutex>
#include <queue>
#include <condition_variable>
#include "SSFIdefaulttypes.hpp"

/*
@brief

Implementation of Queue class that has thread synchronization 
allows the enqueue- (by Search Thread) and Dequeue (by Worker Thread) 
of fileNames/filepaths concurrently 

Use of Mutex for synchronization 
       condition variable for availability and completion

Reference : https://www.quantnet.com/threads/c-multithreading-in-boost.10028/
Queue Class with thread synchronization (General Implementation)

*/
template <typename T>
class SynchronizedQueue{

private: 
	queue<T> s_queue;//allow unique paths 
	mutex s_mutex;//protection of dequeue and enqueue 
	condition_variable s_cond;//notification of 

	//Synchronizaztion of end 
	bool requestoEnd ;
	bool enqueueData ;

	void completeActions(){
		enqueueData = false;
		DEBUG_PRINT("Complete Actions");
		}
public:
	SynchronizedQueue(){
		requestoEnd = false;
		enqueueData = true;
	}

	//Add data<Enqueue> to the queue and notify others 
	void Enqueue(const T& data)	{
		unique_lock<mutex> lock(s_mutex);//Acquire Lock before adding data
		DEBUG_PRINT("\n  Enqueue Fx \n "); 
		if(enqueueData){
			s_queue.push(data);//Add data
			s_cond.notify_one();//notify one thread as data is avaialble on queue
		}	
		lock.unlock();
	}//Lock released at end of scope 

	//Dequeue Type T elements from Queue 
	T Dequeue(){

		unique_lock<mutex> lock(s_mutex);//Acquire Lock before reterieve  data
		DEBUG_PRINT("Dequeue Fx \n");
		
		while (s_queue.size()==0 && !requestoEnd){//check if request end or empty queue
			s_cond.wait(lock);//Wait for notification 
		}

		if(requestoEnd && s_queue.size()==0){//Check for completions 
			completeActions();
			return "";
		}else{
			
			T dequeueData = s_queue.front();
			s_queue.pop();

			return dequeueData;
		}	
	}//lock released here 


	void StopQueue(){
		unique_lock<mutex> lock(s_mutex);//Acquire Lock before adding data
		DEBUG_PRINT("StopQueue Fx ");
		requestoEnd = true;
		s_cond.notify_all();//Notify every waiting thread 
	}

	bool try_Dequeue(){
		unique_lock<mutex> lock(s_mutex);//Acquire Lock before adding data
		if(s_queue.size()==0 && requestoEnd){//to check data on queue available 
			return true;
		}
		return false;
	}

};
#endif
