#ifndef _SSFIDEFAULTTYPES
#define _SSFIDEFAULTTYPES

#include <string>
#include <map>
#include <boost/filesystem.hpp>
/*
@brief 
 	Provides default values and typedefs to SSFI

*/
using namespace std;
using namespace boost::filesystem;

// using Print debugger or gdb
//Uncomment next line to enable debugging
//#define DEBUGLEVEL

#ifdef DEBUGLEVEL
	#define DEBUG 1
#else
	#define	DEBUG 0
#endif

#define DEBUG_PRINT(fmt, args...) \
        do { if (DEBUG) fprintf(stderr, "\n %s:%d:%s(): " fmt, __FILE__, \
                                __LINE__, __FUNCTION__, ##args); } while (0)

#define MAXDIRSIZE 5000
#define DEFAULTWORKERTHREADS 10        
#define TOPWORDSLIST 10
#define DEFAULT_FILE_INDEXER ".txt"



typedef enum Error_codes_t {STATUS_OK,ERROR_FILEOPEN,ERROR_DIR} Error_codes;

typedef struct Parameters
{
	char directoryPath[MAXDIRSIZE];
	int numOfWorkerThreads;
	
}Parameters_t;



typedef vector<pair<string,int>> mapCopy_t;

// A new defintion for comparision used by map for case insensitivity
//Ref :http://www.davekb.com/browse_programming_tips:stl_case_insensitive_map:txt
struct caseInsensitive{
	bool operator()(const string & s1,const string & s2)const
	{
		return (strcasecmp(s1.c_str(),s2.c_str()) < 0);
	}

};

typedef map<string,int,caseInsensitive> wordMap_t;

#endif