#ifndef _SEARCHMANAGER_H
#define _SEARCHMANAGER_H

/*
@brief
Search Thread
-------------
SearchManager.cpp :Manages Implementation of Search methods and thread
				  - Implements the spawn of Search Threads. It recursively searches for file paths ( of DEFAULT_FILE_INDEXER) within input directory 
				  - Enqueues the File paths to Syncchronized queue 
				  - Notifies completion of enqueue to worker threads
				  - Notifies end of search within directory 


*/
#include "boost/filesystem/path.hpp"
#include "SyncQueue.hpp"
#include "SSFIdefaulttypes.hpp"
#include "boost/thread.hpp"

//requires Sync Queue 
class Search{

private :
	boost::thread s_thread;
	int s_id;//id of the producer 
	SynchronizedQueue<path>*m_queue;//
	Parameters_t * s_inputParameters;
	void directorySearch(Parameters_t * inputParameters,SynchronizedQueue<path> *m_queue);

public:

	//Construtor with id and queue to use 
	Search(int id,SynchronizedQueue<path>*queue,Parameters_t * inputParameters);
	void startThread();
	void joinThread();

}; 

#endif