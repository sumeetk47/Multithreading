#include "../include/SearchManager.hpp"


//Construtor with id and queue to use 
Search::Search(int id,SynchronizedQueue<path>*queue,Parameters_t * inputParameters)	{
	s_id = id;
	m_queue = queue;
	s_inputParameters=inputParameters;
}

void Search::startThread(){
	DEBUG_PRINT("Start of search thread");
	s_thread = boost::thread(&Search::directorySearch,this,s_inputParameters,m_queue);
}

void Search::joinThread(){
	if(s_thread.joinable()){
		s_thread.join();
	}
}

/*
Recursive Searhing of Files within specified directory and sub directories

1. Search for files recursively within directory 
2. Store file names (complete path) on shared vector of strings
3. Enqueue File paths to Synq Queue

References:
1) http://www.boost.org/doc/libs/1_48_0/libs/filesystem/v3/doc/reference.html#class-path
2) http://stackoverflow.com/questions/9366040/search-files-in-directory-and-subdirectory-using-boost-library-c
*/
//typedef vector<path> pathVector_t;
void Search::directorySearch(Parameters_t * inputParameters,SynchronizedQueue<path> *m_queue){

	//Recursive search 
	path directoryPath(inputParameters->directoryPath);
	string ext = DEFAULT_FILE_INDEXER;// From DEFAULT_FILE_INDEXER
	DEBUG_PRINT("Entry of Directory Search %s ",inputParameters->directoryPath);
	
	try {
		if(exists(directoryPath)){
			if(is_directory(directoryPath)){//check directory or not 							
				
				//Search and add full File Paths to vector 
				recursive_directory_iterator it(directoryPath);
				recursive_directory_iterator endit;

				while (it !=endit){
					if(is_regular_file(*it) && it->path().extension() == ext){
						DEBUG_PRINT("Enqueue :: %s",it->path().c_str());
						m_queue->Enqueue(it->path().string());
					}	
					++it;
					DEBUG_PRINT("Directory %s",directoryPath.c_str()) ;	
				}		
			}
			else{
				cout << directoryPath << " is Present ,but not Directory " << endl ;	
			
			}
		}
		else{
			cout << directoryPath << " does not exists " << endl ;	
			
		}
		m_queue->StopQueue();//Indication of completion of Search Thread/Directory Search to Worker Threads	
							//Also in state of not finding directory
	}
	
	catch (const filesystem_error& ex){
		cout << ex.what();
		cout << "Error return";
		return;
	}
	DEBUG_PRINT("End of Search Thread  %s ",inputParameters->directoryPath);
	return;
}	
