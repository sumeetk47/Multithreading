/*
Implementation of Super Simple File Indexer(SSFI)

SoldFire Coding Assignment 

Author- chinmay.shah@colorado.edu

@brief
Driver code for SSFI
	1) Input from command line are validated and set
	2) SSFI functionality called

*/

#include <iostream>
#include "../include/SSFIdefaulttypes.hpp"
#include "../include/SSFI.hpp"

//Driver Function
int main (int argc,char *argv[]){

	char Path[MAXDIRSIZE];

	if (argc !=4 && argc !=2){
		 cout << "\n USAGE:: ./<Executable> -t <Threads> <directory Path> \n ";
		exit(1);
	}

	Parameters_t *inputParameters=new Parameters_t;

	//Validate input paramters
	if(NULL==inputParameters){
		return 1;
	}
	DEBUG_PRINT("Total Arguments %d",argc);

	if(argc >2){		
		if(!(strcmp(argv[1],"-t"))) {
			inputParameters->numOfWorkerThreads =atoi(argv[2]); 
			strncpy(inputParameters->directoryPath,argv[3],sizeof(Path));
		}	
		else
		{
			cout << "\n Flag unsupported:: -t <No of Worker Threads> \n ";
			exit(1);
		}
	}	
	else{
		
		inputParameters->numOfWorkerThreads = DEFAULTWORKERTHREADS; 
		strncpy(inputParameters->directoryPath,argv[1],sizeof(Path));

	}

	DEBUG_PRINT("Directory : %s \n Max  Working Threads :%d \n",inputParameters->directoryPath,inputParameters->numOfWorkerThreads); 
	
	//Invoking simple Indexer for top <default> words from directory input 
	SSFI simpleIndexer(TOPWORDSLIST);
	simpleIndexer.setSSFIInput(inputParameters);
	simpleIndexer.SimpleFileIndexer();

	delete inputParameters;

}


