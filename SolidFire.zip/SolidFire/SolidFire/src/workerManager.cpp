#include "../include/workerManager.hpp"
#include <fstream>
#include <sstream>

static mutex w_mutex;//shared mutex within different worker threads

//Checking nonalphanumber Value
bool alphaNumFilter(char c ){
	return (isalnum(c)==0);
}	

//Construtor to set id and queue and map 
void Worker::setup(int id,SynchronizedQueue<path>*queue,wordMap_t *wordMap)	{
	w_id = id;
	w_queue = queue;
	w_wordMap = wordMap;
}

/*
Word Counter Implementation 
1) Parse File according to delimters other than a-z,A-Z and 0-9
2) Store the word and count value in hash map 
	-- Match the words (case-insensitive) and increment the counter 
i/p - WorMap , Sync Queue  - dequeue FileName (Complete path)
o/p - hash map {words and count}
Ref:http://stackoverflow.com/questions/4888879/elegant-ways-to-count-the-frequency-of-words-in-a-file

*/
void Worker::wordCounter(wordMap_t *wordMap,SynchronizedQueue<path> *m_queue){	
	ifstream input;
	string indexWord;
	string parseWord;
	wordMap_t &wordIntMap= *wordMap;
	DEBUG_PRINT("Thread Spwaned ");

	while(1){
		if(m_queue->try_Dequeue()){
			break;
		}
		
		string fileName=m_queue->Dequeue().string();	// Dequeue the File	Path names
		DEBUG_PRINT("Outside Dequeue %s",fileName.c_str());
		try{
			input.open(fileName);
			if(!(input)){
				DEBUG_PRINT("Could not open file %s",fileName.c_str());
				break;
			}
		}			
		catch (const filesystem_error& ex){
			cout << ex.what();
			cout << "Error return";
			return;
		}
		while(input >> parseWord ){
			replace_if(parseWord.begin(),parseWord.end(),alphaNumFilter,' ');//remove the punchuation
			//parse and store the word count 
			istringstream parseWordString(parseWord);
			while(parseWordString >> indexWord ){
				w_mutex.lock();//protected for multiple thread usage 
				++(wordIntMap[indexWord]);//counter for each word
				w_mutex.unlock();		
			}
		}	
		DEBUG_PRINT("Closing a file %s",fileName.c_str());
		input.close();	
	}	
}

