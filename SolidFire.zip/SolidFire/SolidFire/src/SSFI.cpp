#include "../include/SyncQueue.hpp"
#include "../include/SearchManager.hpp"
#include "../include/workerManager.hpp"
#include "../include/SSFI.hpp"



template <typename T1,typename T2>
struct descSecond
{
	typedef pair<T1,T2> type;
	bool operator ()(type const &lhs,type const &rhs) const{
		if (lhs.second > rhs.second)
			return true;			
		else
			return false;	
	}
 	
}; 
/* 
@brief
Sort and prints the Top x words from the Map
   Input
   1) Input <x> required top list of words 
   2) Word Map under consideration 
Output
   1) Sorts the input List
   2) prints the top <x> list from the map	

 Ref:http://www.technical-recipes.com/2012/how-to-sort-items-contained-in-stl-maps/
   
*/ 

SSFI::SSFI(int topWordsList){
	s_topWordsList=topWordsList;
}

void SSFI::setSSFIInput(Parameters_t *inputParameters){
		s_inputParameters=inputParameters;
}

void SSFI::printTopWords(mapCopy_t *mapcopy,int numTopWords){
	int dispCount =1;
	vector<pair<string,int>>::iterator it;
	cout << "\n \nTop "<< numTopWords <<" Words of Directory are \n \n";
	//list the top ten words of the Map
	it=mapcopy->begin();
	while (it!=mapcopy->end() && dispCount<=numTopWords){
		
		cout << it->first <<"\t"
				 << it->second << endl; 				
		++it;
		dispCount++;
	}

}

mapCopy_t* SSFI::sortWordMap(wordMap_t *wordMap){


	wordMap_t &wordList= * wordMap;
		
	if(wordList.empty()){	//check if map is empty
		cout << "\n No Text File Found. Try with another directory \n";
		return NULL;
	}	
	mapCopy_t *mapCopy = new mapCopy_t(wordList.begin(),wordList.end());
	sort(mapCopy->begin(),mapCopy->end(),descSecond<string,int>());

	return mapCopy;
}


/*
SSFI - Super Simple File Indexer 
	Responsible for main implementation of SSFI
	1) Spawns Worker Threads and Search Thread
	2) Sorts the Map of Words 
	3) Displays top words in descending order  
*/
void SSFI::SimpleFileIndexer(){

	SynchronizedQueue<path> *m_queue=new SynchronizedQueue<path>;
	
	if(NULL==m_queue){
		cout << "Error Queue: Null Pointer Error";
		return ;
	}


	Search searchFile(1,m_queue,s_inputParameters);
	searchFile.startThread();//Spawning Search Thread
	

	wordMap_t *wordMap = new wordMap_t;

	if(NULL==wordMap){
		cout << "Error Word Map: Null Pointer Error";
		return ;
	}

	//Spawning Worker Threads	
	Worker workerObj[s_inputParameters->numOfWorkerThreads];
	boost::thread* workerThread[s_inputParameters->numOfWorkerThreads];

	for (int i=0;
			i<s_inputParameters->numOfWorkerThreads;
			++i){	
		
		workerObj[i].setup(i,m_queue,wordMap);
		workerThread[i] = new boost::thread(workerObj[i]);		
	}

	
	searchFile.joinThread();//Wait for search Thread to complete 
	
	//Wait for Worker Threads	
	for (int i=0;
			i<s_inputParameters->numOfWorkerThreads;
			i++){			
			workerThread[i]->join();
	}
	
	DEBUG_PRINT("All threads joined");
	
	mapCopy_t *mapCopy=sortWordMap(wordMap);
	if(mapCopy!=NULL){
		printTopWords(mapCopy,s_topWordsList);
	}


	
	//delete the sync queue , wordMap and mapCopy
	delete mapCopy;
	delete m_queue;
	delete wordMap;

}